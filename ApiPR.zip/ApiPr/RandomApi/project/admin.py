from django.contrib import admin

from .models import Joke, Ips

admin.site.register(Joke)
admin.site.register(Ips)
